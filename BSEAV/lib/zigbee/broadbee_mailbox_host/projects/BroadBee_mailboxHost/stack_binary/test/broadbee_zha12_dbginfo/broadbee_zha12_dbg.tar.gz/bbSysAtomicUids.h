/*****************************************************************************************

   Copyright 2013 - 2015 Broadcom Corporation

This program is the proprietary software of Broadcom Corporation and/or its licensors,
and may only be used, duplicated, modified or distributed pursuant to the terms and
conditions of a separate, written license agreement executed between you and Broadcom
(an "Authorized License").  Except as set forth in an Authorized License, Broadcom
grants no license (express or implied), right to use, or waiver of any kind with respect
to the Software, and Broadcom expressly reserves all rights in and to the Software and
all intellectual property rights therein.  IF YOU HAVE NO AUTHORIZED LICENSE, THEN YOU
HAVE NO RIGHT TO USE THIS SOFTWARE IN ANY WAY, AND SHOULD IMMEDIATELY NOTIFY BROADCOM
AND DISCONTINUE ALL USE OF THE SOFTWARE.

Except as expressly set forth in the Authorized License,

1. This program, including its structure, sequence and organization, constitutes the
valuable trade secrets of Broadcom, and you shall use all reasonable efforts to protect
the confidentiality thereof, and to use this information only in connection with your
use of Broadcom integrated circuit products.

2. TO THE MAXIMUM EXTENT PERMITTED BY LAW, THE SOFTWARE IS PROVIDED "AS IS" AND WITH
ALL FAULTS AND BROADCOM MAKES NO PROMISES, REPRESENTATIONS OR WARRANTIES, EITHER EXPRESS,
IMPLIED, STATUTORY, OR OTHERWISE, WITH RESPECT TO THE SOFTWARE.  BROADCOM SPECIFICALLY
DISCLAIMS ANY AND ALL IMPLIED WARRANTIES OF TITLE, MERCHANTABILITY, NONINFRINGEMENT,
FITNESS FOR A PARTICULAR PURPOSE, LACK OF VIRUSES, ACCURACY OR COMPLETENESS, QUIET
ENJOYMENT, QUIET POSSESSION OR CORRESPONDENCE TO DESCRIPTION. YOU ASSUME THE ENTIRE RISK
ARISING OUT OF USE OR PERFORMANCE OF THE SOFTWARE.

3. TO THE MAXIMUM EXTENT PERMITTED BY LAW, IN NO EVENT SHALL BROADCOM OR ITS LICENSORS
BE LIABLE FOR (i) CONSEQUENTIAL, INCIDENTAL, SPECIAL, INDIRECT, OR EXEMPLARY DAMAGES
WHATSOEVER ARISING OUT OF OR IN ANY WAY RELATING TO YOUR USE OF OR INABILITY TO USE THE
SOFTWARE EVEN IF BROADCOM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES; OR (ii)
ANY AMOUNT IN EXCESS OF THE AMOUNT ACTUALLY PAID FOR THE SOFTWARE ITSELF OR U.S. $1,
WHICHEVER IS GREATER. THESE LIMITATIONS SHALL APPLY NOTWITHSTANDING ANY FAILURE OF
ESSENTIAL PURPOSE OF ANY LIMITED REMEDY.

************************** BROADCOM CONFIDENTIAL *****************************************
*
* FILENAME: $Workfile: trunk/stack/prebuild/bbSysAtomicUids_head_h.txt $
*
* DESCRIPTION:
*   Atomic sections UIDs enumeration.
*
* $Revision: 7831 $
* $Date: 2015-07-31 13:31:38Z $
*
*****************************************************************************************/


#ifndef _BB_SYS_ATOMIC_UIDS_H
#define _BB_SYS_ATOMIC_UIDS_H


/************************* INCLUDES *****************************************************/
#include "bbSysOptions.h"           /* Compiler and SYS options setup. */


/************************* DEFINITIONS **************************************************/
/**//**
 * \brief Atomic sections UIDs enumeration.
 */
typedef enum _SysAtomicSectionUid_t
{
    /* Reserved UIDs - from 0x0000'0001 to 0x0000'FFFF. */

    SYS_ATOMIC_DEFAULT_UID                                                                                 = 0x00000000,

    /* These values are generated automatically. Do not edit them manually! */

    /* bbPhyPibApi.h */
    ATM_phyPibApiSetTransmitPower                                                                          = 0x00010000,
    ATM_phyPibApiSetCcaMode                                                                                = 0x00010001,
    ATM_phyPibApiSetCurrentChannelOnPage                                                                   = 0x00010002,
    ATM_phyPibApiGetRssi                                                                                   = 0x00010003,

    /* bbMacLeBeaconsBuffer.c */
    ATM_macLeBeaconsBufferGet                                                                              = 0x00010004,

    /* bbMacLeRealTimeDisp.c */
    ATM_macLeRealTimeDispResetReq                                                                          = 0x00010005,
    ATM_macLeRealTimeDispSetTrxModeReq                                                                     = 0x00010006,
    ATM_macLeRealTimeDispReceiveResp                                                                       = 0x00010007,
    ATM_macLeRealTimeDispStartTxReq                                                                        = 0x00010008,
    ATM_macLeRealTimeDispReadyTxResp                                                                       = 0x00010009,
    ATM_macLeRealTimeDispStartEdReq                                                                        = 0x0001000a,
    ATM_macLeRealTimeDispSetChannelReq                                                                     = 0x0001000b,
    ATM_macLeRealTimeDispCompleteResp                                                                      = 0x0001000c,

    /* bbMacFeReqProcRxEnable.c */
    ATM_macFeReqProcRxEnableIssueConf                                                                      = 0x0001000d,

    /* bbMacPibApi.h */
    ATM_macPibApiSetRxOnWhenIdle                                                                           = 0x0001000e,

    /* bbHalUsart.c */
    UART_WRITE2                                                                                            = 0x0001000f,
    UART_WRITE                                                                                             = 0x00010010,

    /* bbMl507Usart.c */
    UART_ENABLE                                                                                            = 0x00010011,
    UART_DISABLE                                                                                           = 0x00010012,

    /* bbSocUart.c */
    SoC_UART_ENABLE                                                                                        = 0x00010013,
    SoC_UART_DISABLE                                                                                       = 0x00010014,

    /* bbSecurity.c */
    SYS_SECURITY_ENCRYPT_DECRYPT_ATOMIC                                                                    = 0x00010015,

    /* bbSysTaskScheduler.c */
    SYS_SCHEDULER_INIT_0                                                                                   = 0x00010016,
    SYS_SCHEDULER_RUN_TASK_0                                                                               = 0x00010017,
    SYS_SCHEDULER_RUN_TASK_1                                                                               = 0x00010018,
    SYS_SCHEDULER_RUN_TASK_2                                                                               = 0x00010019,
    SYS_SCHEDULER_POST_TASK_0                                                                              = 0x0001001a,
    SYS_SCHEDULER_RECALL_TASK_0                                                                            = 0x0001001b,
    SYS_SCHEDULER_IS_TASK_SCHEDULED_0                                                                      = 0x0001001c,

    /* bbSysFsm.c */
    SYS_FSM_START_EVENT_HANDLING                                                                           = 0x0001001d,
    SYS_FSM_FINISH_EVENT_HANDLING                                                                          = 0x0001001e,

    /* bbSysPriorityQueue.h */
    PRIORITYQUEUE_PUT                                                                                      = 0x0001001f,
    PRIORITYQUEUE_REMOVE                                                                                   = 0x00010020,
    PRIORITYQUEUE_EXTRACT                                                                                  = 0x00010021,

} SysAtomicSectionUid_t;


#endif /* _BB_SYS_ATOMIC_UIDS_H */
