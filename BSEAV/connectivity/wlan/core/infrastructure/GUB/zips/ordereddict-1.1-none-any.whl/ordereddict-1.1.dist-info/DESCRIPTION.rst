This is a handmade wheel containing the compatibility version of
OrderedDict for Python 2.4, 2.5, and 2.6 (from 2.7 on it's built in).
